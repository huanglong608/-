<?php
mysql_connect('localhost:3306','root','root'); //数据库地址、账号、密码
mysql_select_db('root'); //数据表
$sql1 = "ALTER TABLE `shua_tools` ADD `shopimg` text DEFAULT NULL"; //新增字段 如果数据表发生变化 自行改动shua_site即可
/*$sql2 = "ALTER TABLE `shua_tools` ADD `shopimg` text DEFAULT NULL 'http://wx2.sinaimg.cn/mw690/0060lm7Tly1fr3rqjyob0j304q0643z5.jpg'"*/
mysql_query($sql1); //这里可发生变化,默认执行sql1,可填sql2 （两者区别:sql1不会新增图片,sql2会给所有商品设置同一张商品图）
//填写sql2是请将sql1注释,将sql2的注释删除。
//有疑问请联系QQ：2306972258
?>  