<?php
$authcode='';
$distid='4c';
?>